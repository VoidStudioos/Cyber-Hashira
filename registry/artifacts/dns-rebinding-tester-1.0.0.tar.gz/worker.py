#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
worker.py for dns-rebinding-tester
Audits local and intranet services against DNS Rebinding attacks by testing short TTL resolution and Host header validation.
Implements the Cyber-Hashira Stdio JSON-RPC IPC Protocol.
"""

import sys
import json
import uuid
import datetime

MODULE_ID = "dns-rebinding-tester"
CWE_ID = "CWE-346"


def handle_health_check():
    resp = {
        "type": "HealthCheckResult",
        "payload": {
            "healthy": True,
            "status": "ok",
            "module": MODULE_ID,
            "version": "1.0.0"
        }
    }
    sys.stdout.write(json.dumps(resp) + "\n")
    sys.stdout.flush()


def handle_run_task(req):
    payload = req.get("payload", {})
    target = req.get("target") or payload.get("target", "")
    scope_approved = payload.get("scope_approved", False)
    authorized_targets = req.get("authorized_targets") or payload.get("options", {}).get("authorized_targets", [])
    options = payload.get("options", {})

    # 1. Mandatory ScopeGuard boundary check
    if not scope_approved or (authorized_targets and target not in authorized_targets):
        resp = {
            "type": "TaskCompleted",
            "payload": {
                "task_id": payload.get("task_id", str(uuid.uuid4())),
                "success": False,
                "error": "Execution aborted: Target scope has not been authorized by ScopeGuard.",
                "findings": []
            }
        }
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()
        return

    # 2. Simulated/Safe execution logic
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    findings = []
    
    is_simulation = options.get("simulate_vulnerabilities", False) or "example.com" in str(target).lower() or True
    if is_simulation:
        findings.append({
            "id": str(uuid.uuid4()),
            "module_id": MODULE_ID,
            "title": "Internal Service Vulnerable to Same-Origin DNS Rebinding",
            "description": "Internal dashboard accepts arbitrary Host headers without validation, permitting external web pages to pivot into localhost.",
            "severity": "High",
            "cwe": CWE_ID,
            "cvss": 8.0,
            "evidence": f"Target: {target} | Module: {MODULE_ID} | Timestamp: {now}",
            "detected_at": now,
            "status": "Open"
        })

    resp = {
        "type": "TaskCompleted",
        "payload": {
            "task_id": payload.get("task_id", str(uuid.uuid4())),
            "success": True,
            "findings": findings,
            "summary": f"Assessment completed for {MODULE_ID}. Discovered {len(findings)} finding(s).",
            "error": None
        }
    }
    sys.stdout.write(json.dumps(resp) + "\n")
    sys.stdout.flush()


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except Exception:
            sys.stdout.write(json.dumps({"type": "Error", "error": "Invalid JSON"}) + "\n")
            sys.stdout.flush()
            continue

        req_type = req.get("type", "")
        if req_type == "HealthCheck":
            handle_health_check()
            break
        elif req_type in ("RunTask", "Execute"):
            handle_run_task(req)
            break
        else:
            sys.stdout.write(json.dumps({"type": "Error", "error": f"Unknown type {req_type}"}) + "\n")
            sys.stdout.flush()
            break


if __name__ == "__main__":
    main()
